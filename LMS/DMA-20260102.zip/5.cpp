//for allocating memory dynamically for an 1-D array :
#include<iostream>
using namespace std;
int main()
{
int n,i;
cout<<"enter the n size"<<endl;
cin>>n;

int *p=new int[n];

cout<<"enter the elements"<<endl;
for(i=0;i<n;i++)
{
cin>>p[i];

}
cout<<"display the elements"<<endl;
for(i=0;i<n;i++)
{
cout<<"p["<<i<<"]="<<p[i]<<endl;
}
cout<<"after deallocating "<<endl;
delete [] p;//deallocating memory
p=NULL;
for(i=0;i<n;i++)
{
cout<<"p["<<i<<"]="<<p[i]<<endl;
}
}
