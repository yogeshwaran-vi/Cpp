//DMA in C++
#include<iostream>
using namespace std;
int main()
{
int *p1=new int(20);// allocating memory for single integer 
cout<<"p1="<<p1<<endl;
cout<<"*p1="<<*p1<<endl;
cout<<"after deallocating"<<endl;
delete p1;// deallocating memory 
p1=NULL;
cout<<"p1="<<p1<<endl;
cout<<"*p1="<<*p1<<endl;


}


