reference to pointer

syntax:

datatype *&ref_var=pointervar;
