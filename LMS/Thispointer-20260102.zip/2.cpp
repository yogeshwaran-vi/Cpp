//this pointer 
#include<iostream>
using namespace std;
class A
{
public:
int x;// data member 
public:
void print() //void A::print(struct A *const this)
{
cout<<"print function is called"<<endl;
cout<<"current object address="<<this<<endl;// 2000
cout<<"x="<<x<<endl;// this -> x
                   //(&ob2)->x



}
};
int main()
{
A ob1,ob2;

cout<<"address of object1="<<&ob1<<endl;
cout<<"address of object2="<<&ob2<<endl;
cout<<"display the ob2 data"<<endl;
ob2.print();//A::print(&ob2)

}
