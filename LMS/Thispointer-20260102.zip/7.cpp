//this pointer
#include<iostream>
using namespace std;
class B
{
public:
int x;//data member 
public:
void setdata() //void B::setdata(struct B *const this)
{
cout<<"enter the x value.."<<endl;
cin>>x;//&this->x
}
void print() //void B::print(struct B *const this)
{
cout<<"x="<<x<<endl; //this->x
                    //(&ob1)->x
}
};
int main()
{
B ob1;

cout<<"address of object 1="<<&ob1<<endl;
cout<<"enter the ob1 data"<<endl;
ob1.setdata();//B::setdata(&ob1)
cout<<"display the ob1 data"<<endl;
ob1.print();// B::print(&ob1)
}

