//this pointer
#include<iostream>
using namespace std;
class A
{
public:
int x;// data member
public:
void print()  //void A::print(struct A *const this)
{
cout<<"print function is called"<<endl;
cout<<"current object address="<<this<<endl;// 1000

cout<<"x="<<x<<endl;// this->x
                   //(&ob1)->x

} 
};
int main()
{
A ob1;

cout<<"address of object 1="<<&ob1<<endl;
cout<<"display the ob1 data"<<endl;
ob1.print();//A::print(&ob1)


}
