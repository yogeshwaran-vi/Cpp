//this pointer 
#include<iostream>
using namespace std;
class A
{
private:
int x;// data member 
public:
void setdata(int a) //void A::setdata(struct A *const this,int a)
{
this->x=a; //(&ob1)->x=a
            //(&ob1)->x=10
}
void print() //void A::print(struct A *const this)
{
cout<<"print function is called"<<endl;
cout<<"current object address="<<this<<endl; //1000
cout<<"x="<<x<<endl;//this->x
                    //(&ob1)->x
}



};
int main()
{
A ob1;
cout<<"address of object1="<<&ob1<<endl;
cout<<"enter the ob1 data"<<endl;
ob1.setdata(10); //A::setdata(&ob1,10)
cout<<"display the ob1 data"<<endl;
ob1.print();//A::print(&ob1)
}

