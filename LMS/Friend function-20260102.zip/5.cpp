//Real Time Example
//friend  function
#include<iostream>
using namespace std;
class Bank;// forward declaration
          // it informs to the compiler that class bank specifications will be appear later
class ATM
{
public:
void cash(Bank &ob4);
void deposit(Bank &ob5);
void balance(Bank &ob6);
};
class Bank
{
private:
char name[20],accno[20]; //data member 
int sal;   // data member 
public:
void setdata()
{
cout<<"---------------------------------------------"<<endl;
cout<<"welcome to AXIS BANK"<<endl;
cout<<"enter the name..."<<endl;
cin>>name;
cout<<"enter the accno.."<<endl;
cin>>accno;
cout<<"enter the salary..."<<endl;
cin>>sal;
cout<<"------------------------------------------------"<<endl;
}
void print()
{
cout<<"---------------------------------------------"<<endl;
cout<<"Display the AXIS BANK Account Holder........."<<endl;
cout<<"name="<<name<<endl;
cout<<"accno="<<accno<<endl;
cout<<"sal="<<sal<<endl;
cout<<"----------------------------------------------"<<endl;
}
friend void ATM::cash(Bank &ob4);// given permission for particular member function
  // class bank data member can access only one specific member function from 
 //class ATM                           

friend void ATM::deposit(Bank &ob5);

friend void ATM:: balance(Bank &ob6);

};

void ATM::cash(Bank  &ob4) //define member function outside the class
{
int w;
cout<<"cash withdraw function is called"<<endl;
cout<<"enter the cash withdraw amount"<<endl;
cin>>w;

ob4.sal=ob4.sal-w;
cout<<"ob4.sal="<<ob4.sal<<endl;

}
void ATM::deposit(Bank  &ob5) //define member function outside the class
{
int d;
cout<<"deposit function is called"<<endl;
cout<<"enter the deposit amount"<<endl;
cin>>d;
ob5.sal=ob5.sal+d;

cout<<"ob5.sal="<<ob5.sal<<endl;

}
void ATM::balance(Bank &ob6)
{
cout<<"balance function  is called"<<endl;

cout<<"ob6.sal="<<ob6.sal<<endl;
}

int  main()
{
Bank ob1;
ATM ob2;
int op;
while(1)
{
cout<<"enter the option 1) setdata 2) print 3) cash 4) deposit 5) balance 6) Exit"<<endl;
cin>>op;
switch(op)
{
case 1: ob1.setdata();
        break;
case 2:ob1.print();
       break;
case 3:ob2.cash(ob1);//ob1 data passed to the member function explicitly
       break;
case 4:ob2.deposit(ob1);//ob1 data passed to the member function explicitly
       break;
case 5:ob2.balance(ob1);
       break;
case 6:cout<<"EXIT"<<endl;
        return 0;
default:cout<<"invalid option"<<endl;
          return 0;
}
}
}

