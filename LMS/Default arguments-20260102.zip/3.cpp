//Function overloading 
#include<iostream>
using namespace std;
void fun(int);
void fun(int&);
int main()
{
	int a=10;
	fun(a);  //matches with both definition, so it leads to ambiguity
}
void fun(int x)
{
	cout<<"x = "<<x<<endl;
}
void fun(int &y)
{
	cout<<"y = "<<y<<endl;
}
