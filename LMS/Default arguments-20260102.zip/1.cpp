#include<iostream>
using namespace std;
void fun(int,int,int=30);
int main()
{
	fun(10,20);
	fun(11,22,33);
}
void fun(int i,int j,int k)
{
	cout<<"i = "<<i<<" j = "<<j<<" k = "<<k<<endl;
}
