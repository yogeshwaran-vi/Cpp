//Function overloading with default arguments
#include<iostream>
using namespace std;
void fun(int,int);
void fun(int,int,int=30);
int main()
{
	fun(10,20);  // function call matches with both function definition, so it leads to ambiguity
}
void fun(int i,int j)
{
	cout<<"i = "<<i<<" j = "<<j<<" k = "<<k<<endl;
}
void fun(int i,int j,int k)
{
	cout<<"i = "<<i<<" j = "<<j<<" k = "<<k<<endl;
}
