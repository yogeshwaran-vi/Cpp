#include<iostream>
using namespace std;
int main()
{
setlocale(LC_ALL,"");
wchar_t x=0x01f525;
wcout<<x<<endl;
wcout<<sizeof(wchar_t)<<endl;
}

