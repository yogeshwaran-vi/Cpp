#include<iostream>
using namespace std;
int main()
{
setlocale(LC_ALL,"");
wchar_t  x[20]={0x01f923,' ',' ',0x01f525,' ',' ',0x02620,' ',' ',0x01f64c,' ',' ',0x01f64f};

wcout<<x<<endl;
wcout<<sizeof(wchar_t)<<endl;
wcout<<sizeof(x)<<endl;

}
