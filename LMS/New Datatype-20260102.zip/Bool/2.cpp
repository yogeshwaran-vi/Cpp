//bool datatype
#include<iostream>
using namespace std;
int main()
{
bool x=-1;
if(x==true)
{
cout<<"condition is true"<<endl;
}
else
{
cout<<"condition is false"<<endl;
}
}
