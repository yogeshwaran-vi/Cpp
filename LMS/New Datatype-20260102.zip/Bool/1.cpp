//bool datatype
#include<iostream>
using namespace std;
int main()
{
bool x=false;
cout<<"x="<<x<<endl;
cout<<"sizeof(bool)="<<sizeof(bool)<<endl;
}

