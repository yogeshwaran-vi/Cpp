//Assignment-1
//bool datatype
#include<iostream>
using namespace std;
int main()
{
int x=10;
int y=20,z;
bool a=true;
bool b=false;
z=(x|a)+(y|b);
cout<<"z="<<z<<endl;
}

