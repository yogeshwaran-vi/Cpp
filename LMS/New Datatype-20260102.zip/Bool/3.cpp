//bool datatype
#include<iostream>
using namespace std;
int main()
{
bool x;
cout<<"enter the x value.."<<endl;
cin>>x;
if(x==true)
{
cout<<"condition is true"<<endl;
}
else
{
cout<<"condition is false"<<endl;
}
}
