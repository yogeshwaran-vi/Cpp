//string datatype
#include<iostream>
using namespace std;
int main()
{
string str="vector";
cout<<"str="<<str<<endl;
cout<<"str.length()="<<str.length()<<endl;
cout<<"str.append()="<<str.append("A")<<endl;
cout<<"str.insert()="<<str.insert(1,"B")<<endl;
//cout<<"str.erase()="<<str.erase(1,4)<<endl;
//cout<<"str.erase()="<<str.erase(1,1)<<endl;
cout<<"str.erase()="<<str.erase()<<endl;
}
