#include<iostream>
using namespace std;
int main()
{
char a[20];
cout<<"enter  the name.."<<endl;
cin.getline(a,sizeof(a));
cout<<"a="<<a<<endl;
}

