#include<iostream>
using namespace std;
int main()
{
string str1,str2;
cout<<"enter the string1"<<endl;
cin>>str1;
cout<<"enter the string 2"<<endl;
cin>>str2;
if(str1==str2) //strcmp
{
cout<<"Two strings are equal"<<endl;
}
else
{
cout<<"Two strings are not equal"<<endl;
}
}

