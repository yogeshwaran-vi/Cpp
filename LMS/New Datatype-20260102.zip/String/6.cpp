#include<iostream>
using namespace std;
int main()
{
string str1;
string str2;
cout<<"enter the string1"<<endl;
getline(cin,str1);
cout<<"enter the string2"<<endl;
getline(cin,str2);
cout<<"before swapping"<<endl;
cout<<"str1="<<str1<<endl;
cout<<"str2="<<str2<<endl;
str1.swap(str2);
cout<<"after swapping"<<endl;
cout<<"str1="<<str1<<endl;
cout<<"str2="<<str2<<endl;
}
