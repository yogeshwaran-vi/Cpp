#include<iostream>
using namespace std;
int main()
{
string str1;
cout<<"enter the string1"<<endl;
getline(cin,str1);
cout<<"str1="<<str1<<endl;
}
