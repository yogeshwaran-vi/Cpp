#include<iostream>
using namespace std;
int main()
{
char a[20];
cout<<"enter  the name.."<<endl;
cin>>a;
cout<<"a="<<a<<endl;
}

