#include<iostream>
using namespace std;
class A
{
int x,y;//by default,private data member 
A(int a,int b)  //by default,private constructor
{
x=a;
y=b;
cout<<"parameterized constructor"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;

}
~A() //by default,private destructor
{
cout<<"destructor"<<endl;

}
};
int main() //non-member function
{
A ob1={10,20};


}
