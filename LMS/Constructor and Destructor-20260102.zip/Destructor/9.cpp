#include<iostream>
using namespace std;
class A
{
private:
int *p;
public:
A()
{
p=new int[5];
cout<<"default constructor"<<endl;
for(int i=0;i<5;i++)
{
cin>>p[i];
}
cout<<"display the elements"<<endl;
for(int i=0;i<5;i++)
{
cout<<"p["<<i<<"]="<<p[i]<<endl;
}
}
~A()
{
delete [] p;
p=NULL;
cout<<"destructor"<<endl;
for(int i=0;i<5;i++)
{
cout<<"p["<<i<<"]="<<p[i]<<endl;
}
}

};
int main()
{
A ob1;

}
