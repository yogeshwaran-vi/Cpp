#include<iostream>
using namespace std;
class A
{
protected:
int x;// data member
public:
A()
{
x=10;//Assignment
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
~A()
{
delete x;//invalid 
cout<<"destructor "<<endl;
cout<<"x="<<x<<endl;
}
};
int main()
{
A ob1;//invoke default constructor
}
