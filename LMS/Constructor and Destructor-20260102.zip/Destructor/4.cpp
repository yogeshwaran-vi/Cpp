#include<iostream>
using namespace std;
class A
{
protected:
int x;// data member
public:
  A()
{
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
~A() 
{
cout<<"destructor"<<endl;
}
};
int main()
{
A ob1,ob2;
}
