#include<iostream>
using namespace std;
class A
{
protected:
int x;// data member
};
int main()
{
A ob1;//invoke default constructor
}
//NOTE1:
//if user doesn't provide default constructor explicitly,
//then internally compiler will provide default constructor

//NOTE2:
//if user doesn't provide destructor explicitly,
//then internally compiler will provide destructor.

