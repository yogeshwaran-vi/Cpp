#include<iostream>
using namespace std;
class A
{
public:
int *p;
public:
A()
{
p=new int(10);
cout<<"default constructor"<<endl;
cout<<"*p="<<*p<<endl;

}
~A()
{
delete p;
p=NULL;
cout<<"destructor"<<endl;
cout<<"*p="<<*p<<endl;
}
};
int main()
{
A ob1;

}
