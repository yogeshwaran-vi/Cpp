//constructor and destructor
#include<iostream>
using namespace std;
class A
{
private:
int x;// data member 
public:
A()
{
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
public:
~A()
{
cout<<"destructor"<<endl;
}

};
int main()
{
{
cout<<"inside the block"<<endl;
A ob1;
}
cout<<"outside the block"<<endl;
A ob2;
}
