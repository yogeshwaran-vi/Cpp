//constructor can be overloaded  but destructor cannot be overloaded 
#include<iostream>
using namespace std;
class A
{
public:
int x,y;//data member 
public:
A(int a)
{
x=a;
cout<<"parameterized constructor 1"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
}
A(int a,int b)
{
x=a;
y=b;
cout<<"parameterized constructor 2"<<endl;

cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
}
~A(int a) //invalid
{
x=a;
cout<<"destructor"<<endl;
cout<<"x="<<x<<endl;
}
~A(int a,int b) //invalid
{
x=a;
y=b;
cout<<"destructor"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
}
};
int main()
{
A ob1(10);

A ob2(20,30);

}

