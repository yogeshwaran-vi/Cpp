//constructor and destructor
#include<iostream>
using namespace std;
class A
{
private:
int x;//data member 
public:
A()
{
x=10;
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
~A()
{
cout<<"destructor"<<endl;
}
};
int main()
{
A ob1; //invoke default constructor only.


}
