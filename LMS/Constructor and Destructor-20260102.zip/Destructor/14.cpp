#include<iostream>
using namespace std;
struct A
{

int x,y; //by default ,public data member 

A(int a,int b)  //by default ,public constructor
{
x=a;
y=b;
cout<<"parameterized constructor"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;

}
~A() //by default,public destructor
{
cout<<"destructor"<<endl;

}
};
int main() //non-member function
{
A ob1={10,20};


}
