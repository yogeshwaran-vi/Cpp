#include<iostream>
using namespace std;
class A
{
protected:
int x,y;// data member
public:
A(int a,int b):x(a),y(b)
{
cout<<"x="<<x<<endl;//10
cout<<"y="<<y<<endl;//20
cout<<"parameterized constructor"<<endl;
cout<<"x="<<x<<endl;//10
cout<<"y="<<y<<endl;//20
}
};
int main()
{
A ob1(10,20);// whenever object gets created,it is automatically invoke 
            //parameterized constructor only.

}
