#include<iostream>
using namespace std;
class A
{
protected:
int x,y;//data member
public:
A();
A(int a);// constructor declaration
A(int a,int b);//constructor declaration
};
A::A()
{
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;

}
A::A(int a)  //constructor definition outside the class
{
x=a;//Assignment  
cout<<"parameterized constructor 1"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
}
A::A(int a,int b)
{
x=a;
y=b;
cout<<"parameterized constructor2"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;

}
int main()
{
A ob1(10);//invoke parameterized constructor 1 

A ob2(20,30);//invoke parameterized constructor 2

A ob3;//invoke default constructor 

}

