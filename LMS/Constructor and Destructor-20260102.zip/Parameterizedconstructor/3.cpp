#include<iostream>
using namespace std;
class A
{
private:
int x;//data member 
public:
A()
{
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
A(int a)
{
x=a;// Assignment
cout<<"parameterized constructor"<<endl;
cout<<"x="<<x<<endl;

}
};
int main()
{
A ob1(10);//invoke parameterized constructor only.

A ob2;//invoke default constructor only.
}

//NOTE:
//if user defined parameterized constructor ,then internally
// compiler will drop default constructor .so compiler will generate error
//To avoid this error
//you need to provide default constructor explicitly.
