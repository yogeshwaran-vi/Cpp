// A constructor can have the default   arguments.
#include<iostream>
using namespace std;
class A
{
private:
int x;//data member 
public:
A(int a=15)
{
x=a;// Assignment
cout<<"parameterized constructor"<<endl;
cout<<"x="<<x<<endl;

}
};
int main()
{
A ob1(10);//invoke parameterized constructor only.

A ob2;//
}

