//move constructor 
#include<iostream>
using namespace std;
class A
{
private:
int x;// data member 
public:
A(int a)
{
x=a;
cout<<"parameterized constructor"<<endl;
cout<<"x="<<x<<endl;
}
A(A  &&ob4)
{

cout<<"move constructor"<<endl;
x=ob4.x;
ob4.x=NULL;

}
void print()
{
cout<<"x="<<x<<endl;
}

};
int main()
{
A ob1(10);//invoke parameterized constructor only.
cout<<"display the ob1 data"<<endl;
ob1.print();
cout<<"after transfer the ob data"<<endl;
A ob2=move(ob1);//invoke move constructor
cout<<"display the ob2 data"<<endl;
ob2.print();
cout<<"display the ob1 data"<<endl;
ob1.print();
}

