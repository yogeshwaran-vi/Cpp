#include<iostream>
using namespace std;
class A
{
private:
int x;
public:
A(int a)
{
x=a;
cout<<"parameterized constructor"<<endl;
cout<<"x="<<x<<endl;
}

void print()
{
cout<<"x="<<x<<endl;
}
};
int main()
{
A ob1(10);// invoke parameterized constructor 
cout<<"display the ob1 data"<<endl;
ob1.print();
A ob2=ob1;// A ob2(ob1);// invoke copy constructor 
cout<<"display the ob2 data"<<endl;
ob2.print();
}
//NOTE1:
//if user doesn't provide copy constructor explicitly.then internally
//compiler will provide copy constructor implicitly.

//NOTE2:
//one object data copied into another object
// with the help of compiler will provide copy constructor implicitly 
