#include<iostream>
using namespace std;
class A
{
public:
int x;// data member 
public:
void print()
{
cout<<"x="<<x<<endl;
}



};
int main()
{
A ob1;

cout<<"display the ob1 data"<<endl;



}
