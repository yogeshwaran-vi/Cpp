#include<iostream>
using namespace std;
struct A
{
int x;//by default,public data member 

A() //by default,public constructor
{
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
};
int main()
{
A ob1;// 

}
