#include<iostream>
using namespace std;
class A
{
public:
int x;//
public:
A() //
{
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
};
int main()
{
A ob1;// 

}
