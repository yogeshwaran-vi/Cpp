#include<iostream>
using namespace std;
class A
{
private:
int x;// data member 
public:
void  A() //invalid,constructor doesn't have return type
{
cout<<"x="<<x<<endl;//g.v
x=10;// Assignment
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;//10
}
};
int main()
{
A ob1;//whenever object gets created,it is automatically invoke default constructor only.



}
