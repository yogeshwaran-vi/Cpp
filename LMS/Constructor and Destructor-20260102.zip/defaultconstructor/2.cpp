#include<iostream>
using namespace std;
class A
{
private:
int x;// data member 
public:
A()
{
cout<<"x="<<x<<endl;//g.v
x=10;// Assignment
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;//10
}
};
int main()
{
A ob1,ob2;//whenever object gets created,it is automatically invoke default constructor only.



}
