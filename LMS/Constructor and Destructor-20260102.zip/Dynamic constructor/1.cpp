#include<iostream>
using namespace std;
class A
{
private:
int x;// data member 
public:
A()
{
cout<<"x="<<x<<endl;//g.v
x=10;//Assignment
cout<<"dynamic default constructor"<<endl;
cout<<"x="<<x<<endl;//10
}
};
int main()
{
A *ptr=new A;//new operator is used to invoke dynamic default constructor 



}
