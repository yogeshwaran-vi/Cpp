//dynamic default constructor

syntax:

classname *pointervariable=new classname
