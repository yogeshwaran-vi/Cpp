//dynamic parameterized constructor

syntax:

classname *pointervariable=new classname(argument)


