//dynamic constructor can have default arguments
#include<iostream>
using namespace std;
class A
{
protected:
int x,y;//data member 
public:
A(int a,int b=15)
{

x=a;//Assignment
y=b;
cout<<"dynamic parameterized constructor "<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
}
};
int main()
{
A *ptr1=new A(10);//invoke  dynamic parameterized constructor 

}

