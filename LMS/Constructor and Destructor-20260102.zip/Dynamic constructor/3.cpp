//dynamic constructor can be overloaded.
#include<iostream>
using namespace std;
class A
{
protected:
int x,y;//data member 
public:
A(int a)
{

x=a;//Assignment
cout<<"dynamic parameterized constructor 1"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
}
A(int a,int b)
{

x=a;//Assignment
y=b;
cout<<"dynamic parameterized constructor 2"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
}
};
int main()
{
A *ptr1=new A(10);//invoke  dynamic parameterized constructor 1

A *ptr2=new A(20,30);//invoke dynamic parameterized constructor 2

}

