#include<iostream>
using namespace std;
class A
{
private:
int x;// data member 
public:
A():x(10)
{
cout<<"x="<<x<<endl;//10
cout<<"dynamic default constructor"<<endl;
cout<<"x="<<x<<endl;//10
}
};
int main()
{
A *ptr=new A;//new operator is used to invoke dynamic default constructor 



}
