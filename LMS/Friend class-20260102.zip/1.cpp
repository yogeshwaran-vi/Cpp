//class and objects
#include<iostream>
using namespace std;
class A
{
private:
int x;// data member
friend class B;// given permission for class B
               // class B can be access  class A data member 
};
class B
{
  public:
void  print(A  &ob4)
{
cout<<"print function is called"<<endl;
cout<<"ob4.x="<<ob4.x<<endl;
}




};


int main()
{
A ob1;
B ob2;

ob2.print(ob1);



}
