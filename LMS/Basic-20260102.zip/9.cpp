//scope resolution operator(::)
#include<iostream>
using namespace std;
int main()
{
int x=10;//local variable
cout<<"::x="<<::x<<endl;
}
