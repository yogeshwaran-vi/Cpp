//reference variable
#include<iostream>
using namespace std;
int main()
{
int x=10,y=20;
int &r=x;//it must be initialized .
cout<<"Value of x="<<x<<endl;//10
cout<<"address of x="<<&x<<endl;//1000
cout<<"value of r="<<r<<endl;//10
cout<<"address of r="<<&r<<endl;//1000
cout<<"value of y="<<y<<endl;//20
cout<<"address of y="<<&y<<endl;//2000

r=y;
cout<<"after modify"<<endl;
cout<<"value of x="<<x<<endl;//20
cout<<"address of x="<<&x<<endl;//1000
cout<<"value of r="<<r<<endl;//20
cout<<"address of r="<<&r<<endl;//1000
cout<<"value of y="<<y<<endl;//20
cout<<"address of y="<<&y<<endl;//2000
}

