//reference variable cannot be point to NULL.
#include<iostream>
using namespace std;
int main()
{
int &r=0;
cout<<"r="<<r<<endl;

}

