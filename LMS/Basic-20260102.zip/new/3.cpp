#include<iostream>
using namespace std;
int main()
{
int *p=0;
cout<<"p="<<*p<<endl;



}

