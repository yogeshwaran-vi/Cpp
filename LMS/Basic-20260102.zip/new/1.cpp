//pointer 
#include<iostream>
using namespace std;
int main()
{
int x=10,y=20;
int *p;
cout<<"value of x="<<x<<endl;//10
cout<<"address of x="<<&x<<endl;//1000
p=&x;
cout<<"value of p="<<*p<<endl;//*(1000)=10
cout<<"address of p="<<&p<<endl;//2000
p=&y;
cout<<"value of p="<<*p<<endl;//*(3000)=20
cout<<"address of p="<<&p<<endl;// 2000
}
