//input and output operations
#include<iostream>
using namespace std;
int main()
{
float ch;
cout<<"enter the ch value.."<<endl;
cin>>ch;
cout<<"ch="<<ch<<endl;
}
