#include<iostream>
using namespace std;
int main()
{
int x=10;
cout<<"x="<<x<<endl;
cout<<"hex="<<hex<<x<<endl;
cout<<"oct="<<oct<<x<<endl;
}
