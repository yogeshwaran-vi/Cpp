#include<iostream>
using namespace std;
int main()
{
cout<<"welcome"<<endl;
cout<<"vector"<<endl;
cout<<"india"<<endl;
cout<<"chennai"<<endl;
}

