#include<iostream>
using namespace std;
int main()
{
cerr<<"welcome"<<endl;
cerr<<"vector"<<endl;
cerr<<"india"<<endl;
cerr<<"chennai"<<endl;
}

