//structure in C++
#include<iostream>
using namespace std;
struct st
{
void fun1()// functions are allowed inside the structure 
{
cout<<"welcome"<<endl;
}
}s1;
int main()
{




}
