//structure in C
#include<stdio.h>
struct  st
{
   void fun()// functions are not allowed inside the structure 
{
printf("welcome\n");
}



}s1;
int main()
{





}
