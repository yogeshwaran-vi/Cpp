#include<stdio.h>
int x=10;// global variable
int x=20;// global variable 
int main()
{
printf("x=%d\n",x);
}
