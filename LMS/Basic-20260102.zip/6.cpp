//input and output operations
#include<iostream>
using namespace std;
int main()
{
int x,y;
cout<<"enter the x and y value.."<<endl;
cin>>x>>y;
cout<<"x="<<x<<endl<<"y="<<y<<endl;
}
