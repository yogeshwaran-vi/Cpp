#include<iostream>
int main()
{
std::cout<<"welcome"<<std::endl;
std::cout<<"vector"<<std::endl;
std::cout<<"india"<<std::endl;
std::cout<<"chennai"<<std::endl;
}

