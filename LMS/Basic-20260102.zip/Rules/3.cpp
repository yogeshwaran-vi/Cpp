//case 3
#include<iostream>
using namespace std;
int main()
{
int x=10; //non-const existing variable
const int &r=x;// const reference variable 

cout<<"x="<<x<<endl;
cout<<"address of x="<<&x<<endl;
cout<<"r="<<r<<endl;
cout<<"address of r="<<&r<<endl;
//r++;//invalid
x++;//valid 
cout<<"after modify"<<endl;
cout<<"x="<<x<<endl;
cout<<"r="<<r<<endl;

}
