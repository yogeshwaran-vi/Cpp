//case 1:
#include<iostream>
using namespace std;
int main()
{
int x=10; //non-const existing variable
int &r=x;// non-const reference variable 

cout<<"x="<<x<<endl;
cout<<"address of x="<<&x<<endl;
cout<<"r="<<r<<endl;
cout<<"address of r="<<&r<<endl;


}
