//case 4:
#include<iostream>
using namespace std;
int main()
{
const int x=10; //const existing variable
const int &r=x;// const reference variable 

cout<<"x="<<x<<endl;
cout<<"address of x="<<&x<<endl;
cout<<"r="<<r<<endl;
cout<<"address of r="<<&r<<endl;
//r++;//invalid
x++;//invalid 
cout<<"after modify"<<endl;
cout<<"r="<<r<<endl;
cout<<"x="<<x<<endl;

}
