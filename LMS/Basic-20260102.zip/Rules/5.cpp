//case 5
#include<iostream>
using namespace std;
int main()
{
int &r=10;//invalid 
cout<<"r="<<r<<endl;
}

