//case 2:
#include<iostream>
using namespace std;
int main()
{
const int x=10; //const existing variable
int &r=x;// non-const reference variable    }invalid 

cout<<"x="<<x<<endl;
cout<<"address of x="<<&x<<endl;
cout<<"r="<<r<<endl;
cout<<"address of r="<<&r<<endl;


}
