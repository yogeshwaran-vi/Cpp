//double pointer(pointer to pointer)
#include<iostream>
using namespace std;
int main()
{
int x=10;
int *p=&x;
cout<<"value of x="<<x<<endl;
cout<<"address of x="<<&x<<endl;
cout<<"value of p="<<*p<<endl;
cout<<"address of p="<<&p<<endl;
int **dp=&p;
cout<<"value of dp="<<**dp<<endl;
cout<<"address of dp="<<&dp<<endl;




}
