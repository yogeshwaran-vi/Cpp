//Single inheritance
#include<iostream>
using namespace std;
//base class
class A
{
protected:
int x;// data member 
};
//derived class
class B:public A
{
//derived class inherits all the properties from base class 
//internally
//protected:
//int x;
public:
void print()
{
cout<<"x="<<x<<endl;// u can access base class protected data member 
}

};
int main()
{
A a1;
B b1;
b1.print();
}

