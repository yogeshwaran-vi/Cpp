//Single inheritance
#include<iostream>
using namespace std;
//base class
class A
{
private:
int x;// data member
friend class B;// given permission for class B
               // class B can be access class A data member 
};
//derived class
class B:public A
{
public:
void print()
{
cout<<"x="<<x<<endl;
}
};
int main()
{
A a1;
B b1;
b1.print();
}
