//Single Inheritance	
#include<iostream>
using namespace std;
//base class
class base
{
public:
int x;// data member 

};
//derived class
class derived:public base
{
//derived class inherits all the properties from base class 
//internally
//public:
//int x;
};
int main() //non-member function
{
base b1;
derived d1;
b1.x=10;//base class object can access base class data member
d1.x=20;// derived class object can access base class data member 
cout<<"b1.x="<<b1.x<<endl;
cout<<"d1.x="<<d1.x<<endl;
cout<<"sizeof(base)="<<sizeof(b1)<<endl;
cout<<"sizeof(derived)="<<sizeof(d1)<<endl;
}



