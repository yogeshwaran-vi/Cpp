//Single inheritance
#include<iostream>
using namespace std;
//base class
class A
{
private:
int x;// data member 
};
//derived class
class B:private A
{
//derived class cannot be inherits all the properties from base class
public:
void print()
{
cout<<"x="<<x<<endl;
}



};
int main()
{
A a1;
B b1;
b1.print();


}

