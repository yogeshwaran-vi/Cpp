//single inheritance
#include<iostream>
using namespace std;
//base class
class A
{
protected:
int x;// data member 
public:
void setdata()
{
cout<<"enter the x value.."<<endl;
cin>>x;
}
void print()
{
cout<<"display the  x value.."<<endl;
cout<<"x="<<x<<endl;
}
};

//derived class
class B:public A
{
//derived class inherits all the properties from base class
//internally
//protected:
//int x;
//internally
//public:
//void setdata()
//{
    //   -----
  // }
//void print()
//{
//-----
//}
};

int main() //non-member function
{
A a1;
B b1;
b1.setdata();
b1.print();
}

