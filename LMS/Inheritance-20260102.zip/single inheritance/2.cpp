//Single inheritance
#include<iostream>
using namespace std;
//base class
class base
{
public:
int x;// data member 
};
//derived class
class derived:public base
{
//derived class inherits all the properties from base class
//internally
//public:
//int x;
public:
int y;//to add extra features in  derived class

};
int main()
{
base b1;
derived d1;
b1.x=10;
d1.x=20;
d1.y=30;//derived class object can access derived class data member 
//b1.y=40;//base class object cannot be access derived class data member 
cout<<"b1.x="<<b1.x<<endl;
cout<<"d1.x="<<d1.x<<endl;
cout<<"d1.y="<<d1.y<<endl;
cout<<"sizeof(base)="<<sizeof(b1)<<endl;
cout<<"sizeof(derived)="<<sizeof(d1)<<endl;
}




