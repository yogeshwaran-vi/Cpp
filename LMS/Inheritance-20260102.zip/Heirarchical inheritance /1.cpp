//Heirarchical inheritance: 
#include<iostream>
using namespace std;
//base class
class A
{
public:
int x;// data member 


};
//derived 1 class
class B:public A
{
//derived 1 class inherits all the properties from base class 
//internally
//public:
//int x;
public:
int y,tot;
public:
void setdata()
{
cout<<"------------class B------------"<<endl;
cout<<"enter the  x value and y.."<<endl;
cin>>x>>y;
}
void add()
{
tot=x+y;
}
void print()
{
cout<<"----------------------------"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
cout<<"total="<<tot<<endl;
cout<<"---------------------------"<<endl;
}
};

//derived 2 class
class C:public A
{
//derived 2 class inherits all the properties from base class
//internally
//public:
//int x;
public:
int m,n;
public:
void getdata()
{
cout<<"------------------"<<endl;
cout<<"class -C"<<endl;
cout<<"enter the x and n"<<endl;
cin>>x>>n;
cout<<"-----------------------"<<endl;
}
void sub()
{
m=x-n;
}
void putdata()
{
cout<<"---class C------"<<endl;
cout<<"x="<<x<<endl;
cout<<"n="<<n<<endl;
cout<<"m="<<m<<endl;
cout<<"------------------"<<endl;
}
};
//derived 3 class
class D:public A
{
//derived 3 class inherits all the properties from base class
//internally
//public:
//int x;
public:
int k,j;
public:
void input()
{
cout<<"-----------------------"<<endl;
cout<<"-------class D-----------"<<endl;
cout<<"enter the x and j"<<endl;
cin>>x>>j;
cout<<"-----------------------------"<<endl;
}
void mul()
{
k=x*j;
}
void output()
{
cout<<"--------------------------"<<endl;
cout<<"----------class D-------------"<<endl;
cout<<"x="<<x<<endl;
cout<<"j="<<j<<endl;
cout<<"k="<<k<<endl;
cout<<"-----------------------------"<<endl;
}



};
int main()
{
A a1;

B b1;
b1.setdata();
b1.add();
b1.print();
C c1;
c1.getdata();
c1.sub();
c1.putdata();
D d1;
d1.input();
d1.mul();
d1.output();
}

