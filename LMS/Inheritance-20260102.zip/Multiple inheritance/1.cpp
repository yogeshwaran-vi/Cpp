//Multiple inheritance:
#include<iostream>
using namespace std;
//base class
class supermarket
{
     public:
          char name[20],prod[20];
           int price;
};
//base 2 class
class GST
{
  public:
int cs,ss;//data member 
};
//base 3 class
class discount
{
public:
int d;// data member
};
//derived class
class customer:public supermarket,public GST,public discount
{
//derived class inherits all the properties from base class 
//internally
//public:
//char name[20],prod[20];
//int price;
//public:
// int cs,ss
//public:
//int d;
public:
int tot;
public:
void setdata()
{
cout<<"-----------------------------"<<endl;
cout<<"------welcome to G-MART---------"<<endl;
cout<<".....enter the name..................."<<endl;
cin>>name;
cout<<"enter the product name"<<endl;
cin>>prod;
cout<<"enter the product price"<<endl;
cin>>price;
cout<<"enter the central GST"<<endl;
cin>>cs;
cout<<"enter the state GST"<<endl;
cin>>ss;
cout<<"enter the discount price"<<endl;
cin>>d;
cout<<"-------------------------------------"<<endl;
}
void add()
{
tot=price+cs+ss-d;
}
void print()
{
cout<<"------------------------------------"<<endl;
cout<<"------ welcome to G-MART------------"<<endl;
cout<<"name="<<name<<endl;
cout<<"product="<<prod<<endl;
cout<<"price="<<price<<endl;
cout<<"central gst="<<cs<<endl;
cout<<"state gst="<<ss<<endl;
cout<<"discount price="<<d<<endl;
cout<<"totalamount="<<tot<<endl;
cout<<"thankyou,visit again"<<endl;
cout<<"--------------------------------------"<<endl;
}
};
int main()
{
supermarket s1;
GST g1;
discount d2;
customer c1;
c1.setdata();
c1.add();
c1.print();
}
