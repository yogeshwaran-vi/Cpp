// Hybrid inheritance: 
#include<iostream>
using namespace std;
//base 1 class
class student
{
public:
   char name[20],roll[20];// data member

};
//derived 1 class
class sub:public student
{
//derived 1 class inherits all the properties from base 1 class
//internally
//public:
//char name[20],roll[20];
public:
int mat,phy,chem;

};
//base 2 class
class sports
{
public:
int s;

};
//derived 2 class
class Annauniv:public  sub,public sports
{
//derived 2 class inherits all the properties from derived 1 class
//derived 2 class inherits all the properties from base 2 class
//internally
//public:
//char name[20],roll[20];
//public:
//int mat,phy,chem;
//public:
// int s;
 public:
   int tot,avg;
public:
void setdata()
{
cout<<"-----------------------------"<<endl;
cout<<"enter the student details"<<endl;
cout<<"enter the name..."<<endl;
cin>>name;
cout<<"enter the roll number.."<<endl;
cin>>roll;
cout<<"enter the maths marks"<<endl;
cin>>mat;
cout<<"enter the phy marks"<<endl;
cin>>phy;
cout<<"enter the chem marks"<<endl;
cin>>chem;
cout<<"enter the sports marks"<<endl;
cin>>s;
cout<<"-------------------------------"<<endl;
}
void add()
{
tot=mat+phy+chem+s;
avg=tot/4;
}
void print()
{
cout<<"----------------------------------"<<endl;
cout<<"display the student details"<<endl;
cout<<"name="<<name<<endl;
cout<<"roll no="<<roll<<endl;
cout<<"mat="<<mat<<endl;
cout<<"phy="<<phy<<endl;
cout<<"chem="<<chem<<endl;
cout<<"sports="<<s<<endl;
cout<<"total="<<tot<<endl;
cout<<"avg="<<avg<<endl;
cout<<"---------------------------------------"<<endl;
}
};
int main()
{
student s1;
sub s2;
sports s3;
Annauniv a1;
a1.setdata();
a1.add();
a1.print();
}

