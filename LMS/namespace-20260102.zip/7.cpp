//using directive
#include<iostream>
using namespace std;
namespace A
{
void fun()
{
int x,y,z;
cout<<"namespace A function is called"<<endl;
cout<<"enter the x and y value..."<<endl;
cin>>x>>y;
z=x+y;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
cout<<"z="<<z<<endl;
}
}
namespace B
{
void fun()
{
int x,y,z;
cout<<"namespace B function is called"<<endl;
cout<<"enter the x and y value...."<<endl;
cin>>x>>y;
z=y-x;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
cout<<"z="<<z<<endl;
}
}
int main()
{
{
cout<<"inside the block"<<endl;
using namespace A;
fun();

}
cout<<"outside the block"<<endl;
using namespace B;
fun();
}
