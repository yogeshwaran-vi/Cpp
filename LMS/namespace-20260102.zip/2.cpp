// qualifying the namespace name and scope resolution operator
#include<iostream>
using namespace std;
namespace A
{
int x=10;// global variable
}
namespace B
{
int x=20;//global variable 
}
int main()
{
cout<<"B::x="<<B::x<<endl;
}

