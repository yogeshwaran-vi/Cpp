//class templates
#include<iostream>
using namespace std;
template<class T1,class T2>
class A
{
private:
T1 a;// data member are used template parameter
T2 b;// data member are used template parameter
public:
A(T1 x,T2 y)
{
a=x;
b=y;
cout<<"parameterized constructor"<<endl;
cout<<"a="<<a<<endl;
cout<<"b="<<b<<endl;
}
void print();// function declaration
void modify();
};
template<class T1,class T2>
void A<T1,T2>::print() //define member function outside the class
{
cout<<"a="<<a<<endl;
cout<<"b="<<b<<endl;
}
template<class T1,class T2>
void A<T1,T2>::modify() //define member function outside the class
{
cout<<"modify function is called"<<endl;
a=20;
b=3.4;
cout<<"a="<<a<<endl;
cout<<"b="<<b<<endl;



}
int main()
{
A <int,float> ob1(10,2.3);

cout<<"display the ob1 data"<<endl;
ob1.print();
cout<<"modify function"<<endl;
ob1.modify();
}

