//class templates
#include<iostream>
using namespace std;
template<class T1,class T2>
class A
{
private:
T1 a;// data member are used template parameter
T2 b;// data member are used template parameter
public:
A(T1 x,T2 y)
{
a=x;
b=y;
cout<<"parameterized constructor"<<endl;
cout<<"a="<<a<<endl;
cout<<"b="<<b<<endl;
}
void print()
{
cout<<"a="<<a<<endl;
cout<<"b="<<b<<endl;
}
};
int main()
{
A <int,float> ob1(10,2.3);

cout<<"display the ob1 data"<<endl;
ob1.print();
}

