//class templates
#include<iostream>
using namespace std;
template<class Type>
class A
{
private:
Type a[5];// data member  are used  template parameter 
int i;
public:
void setdata()
{
cout<<"enter the  elements"<<endl;
for(i=0;i<5;i++)
{
cin>>a[i];
}
}
void print()
{
cout<<"display the elements"<<endl;
for(i=0;i<5;i++)
{
cout<<"a["<<i<<"]="<<a[i]<<endl;
}
}
};
int main()
{
A <char> ob1;

ob1.setdata();
ob1.print();
A  <int> ob2;
ob2.setdata();
ob2.print();
}
