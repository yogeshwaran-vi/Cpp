//Assignment-1
1) Write a C++ program to sort data items in ascending order using function templates.

