//reference variable in c++
#include<iostream>
using namespace std;
int main()
{
int x=10;
int &r=x;//alias name of existing variable  
cout<<"value of x="<<x<<endl;//10
cout<<"address of x="<<&x<<endl;//1000
cout<<"value of r="<<r<<endl;//10
cout<<"address of r="<<&r<<endl;//1000
r=20;
cout<<"after modify"<<endl;
cout<<"value of x="<<x<<endl;//20
cout<<"value of r="<<r<<endl;//20
}
