//reference to reference 
#include<iostream>
using namespace std;
int main()
{
int x=10;
int &r=x;// alias name of existing variable 
cout<<"value of x="<<x<<endl;//10
cout<<"address of x="<<&x<<endl;//1000
cout<<"value of r="<<r<<endl;//10
cout<<"address of r="<<&r<<endl;//1000

int &r2=r;//alias name of existing reference variable 

cout<<"value of r2="<<r2<<endl;//10
cout<<"address of r2="<<&r2<<endl;//1000

r2=20;
cout<<"after modify"<<endl;
cout<<"x="<<x<<endl;//20
cout<<"r="<<r<<endl;//20
cout<<"r2="<<r2<<endl;//20

}
