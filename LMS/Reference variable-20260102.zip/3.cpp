//rules of reference variable in C++
#include<iostream>
using namespace std;
int main()
{
int x=10;
int &r;
r=x;//invalid  
cout<<"value of x="<<x<<endl;
cout<<"value of r="<<r<<endl;

}
