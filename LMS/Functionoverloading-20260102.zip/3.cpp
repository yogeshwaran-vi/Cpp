//function overloading
#include<iostream>
using namespace std;
void print(int a) //Name mangling  used for the compiler to provides name to the function
                    // based arguments
                    //_Z5printi

{
cout<<"print int function"<<endl;
cout<<"a="<<a<<endl;
}
void print(double b) //_Z5printd
{
cout<<"print double function"<<endl;
cout<<"b="<<b<<endl;
}
int main()
{
int x=10;
print(x);
double d1=2.3;
print(d1);
}

