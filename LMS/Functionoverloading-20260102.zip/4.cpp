//Rules of Function Overloading in C++
//These  functions have different parameter type
#include<iostream>
using namespace std;
void sum(int a,int b) //_Z3sumii
{
cout<<"sum of int function is called"<<endl;
cout<<"a="<<a<<endl;
cout<<"b="<<b<<endl;
}
void sum(double d1,double d2) //_Z3sumdd
{
cout<<"sum of double function is called"<<endl;
cout<<"d1="<<d1<<endl;
cout<<"d2="<<d2<<endl;
}
int main()
{
int x=10,y=20;
sum(x,y);
double ch=2.3,ch1=4.5;
sum(ch,ch1);
}
