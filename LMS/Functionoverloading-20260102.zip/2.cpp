//function overloading in C++
#include<iostream>
using namespace std;
void sum(int a)// Name mangling  used for the compiler to provides name to the function
                 // based arguments
                 //_Z3sumi
{
cout<<"sum of int function is called"<<endl;
cout<<"a="<<a<<endl;
}
void sum(double b) //_Z3sumd
{
cout<<"sum of double function is called"<<endl;
cout<<"b="<<b<<endl;
}
int main()
{
double d1=2.3;
sum(d1);
int x=10;
sum(x);

}
//NOTE:
//sum function is called,compiler tries to bind exact argument matching function.
//in which actual arguments and formal arguments both should be matched.
//then only invoke  function for execution.
