//function overloading is not possible in C .
#include<stdio.h>
void sum(int a)
{
printf("sum of int function is called\n");
printf("a=%d\n",a);
}
void sum(double b)
{
printf("sum of double function is called\n");
printf("b=%ld\n",b);
}
int main()
{
int x=10;
sum(x);

}
