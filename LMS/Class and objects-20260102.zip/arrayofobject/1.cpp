//class and objects
#include<iostream>
using namespace std;
class A
{
public:
int x;// data member

};
int main() //non-member function
{
A ob1[2];
cout<<"using dot operator"<<endl;
cout<<"ob1[0].x="<<ob1[0].x<<endl;
cout<<"ob1[1].x="<<ob1[1].x<<endl;




}
