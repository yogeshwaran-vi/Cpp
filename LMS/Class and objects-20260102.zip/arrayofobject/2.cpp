//class and objects
#include<iostream>
using namespace std;
class A
{
private:
int x;// data member
public:
void setdata() //member function
{
cout<<"enter the x value.."<<endl;
cin>>x;

}
void print()
{
cout<<"x="<<x<<endl;
}

};
int main() //non-member function
{
A ob1[2];
cout<<"using dot operator"<<endl;
int i;
for(i=0;i<2;i++)
{
ob1[i].setdata();
}
cout<<"display the ob data"<<endl;
for(i=0;i<2;i++)
{
ob1[i].print();
}



}
