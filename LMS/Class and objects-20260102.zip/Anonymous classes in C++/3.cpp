//Anonymous classes in C++
#include<iostream>
using namespace std;
class 
{
protected:
int x;//data member 
public:
void setdata() //member function
{
cout<<"enter the x value.."<<endl;
cin>>x;
}
void print()
{
cout<<"x="<<x<<endl;
}

}ob1[2];
int main() //non-member function
{
int i;
cout<<"enter the ob1 data"<<endl;
for(i=0;i<2;i++)
{
ob1[i].setdata();
}
cout<<"display the ob1 data"<<endl;
for(i=0;i<2;i++)
{
ob1[i].print();
}
}


