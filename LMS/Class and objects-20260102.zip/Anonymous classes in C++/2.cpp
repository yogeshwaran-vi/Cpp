//Anonymous classes in C++
#include<iostream>
using namespace std;
class 
{
protected:
int x;//data member 
public:
void setdata() //member function
{
cout<<"enter the x value.."<<endl;
cin>>x;
}
void print()
{
cout<<"x="<<x<<endl;
}

}ob1,ob2;
int main() //non-member function
{

cout<<"enter the ob1 data"<<endl;
ob1.setdata();
cout<<"enter the ob2 data"<<endl;
ob2.setdata();
cout<<"display the ob1 data"<<endl;
ob1.print();
cout<<"display the ob2 data"<<endl;
ob2.print();

}

