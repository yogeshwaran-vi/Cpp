//friend function 
//class and objects
#include<iostream>
using namespace std;
class A
{
private:
int x;//data member 
friend int  main();
};
int main() //non-member function
{
A ob1;

cout<<"ob1.x="<<ob1.x<<endl;




}
