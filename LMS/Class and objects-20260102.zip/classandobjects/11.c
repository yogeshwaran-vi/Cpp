//structure in C
#include<stdio.h>
struct st
{



}s1;
int main()
{

printf("sizeof(s1)=%d\n",sizeof(s1));
}

