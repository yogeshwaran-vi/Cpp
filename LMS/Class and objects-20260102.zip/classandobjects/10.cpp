//structure in C++
#include<iostream>
using namespace std;
struct st
{
void fun()
{
cout<<"welcome"<<endl;
}
}s1;
int main()
{



}
