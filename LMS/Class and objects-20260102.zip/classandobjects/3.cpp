//Structure in C++
#include<iostream>
using namespace std;
struct A
{
int x; //by default,public data member 
};
int main()//non-member function,it is not part of struct
{
A ob1,ob2;

cout<<"using dot operator"<<endl;
cout<<"ob1.x="<<ob1.x<<endl;
cout<<"ob2.x="<<ob2.x<<endl;
cout<<"sizeof(ob1)="<<sizeof(ob1)<<endl;
cout<<"sizeof(ob2)="<<sizeof(ob2)<<endl;
}











