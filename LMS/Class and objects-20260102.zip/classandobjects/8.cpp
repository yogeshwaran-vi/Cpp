//class and objects
#include<iostream>
using namespace std;
class A
{


};
int main()
{
A ob1;

cout<<"sizeof(ob1)="<<sizeof(ob1)<<endl;
}

