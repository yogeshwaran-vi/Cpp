
#include<iostream>
using namespace std;
class A
{
protected:
int x;//data member 
public:
void setdata();// function declaration
void print();
};
void A::setdata() //define member function outside the class
{
cout<<"enter the  x value.."<<endl;
cin>>x;

}
void A::print()
{
cout<<"x="<<x<<endl;
}
int main() //non-member function
{
A ob1,ob2;
cout<<"enter the ob1 data"<<endl;
ob1.setdata();
cout<<"enter the ob2 data"<<endl;
ob2.setdata();
cout<<"display the ob1 data"<<endl;
ob1.print();
cout<<"display the ob2 data"<<endl;
ob2.print();
}

