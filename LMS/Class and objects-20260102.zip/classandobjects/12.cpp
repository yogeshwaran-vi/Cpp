//structure in C++
#include<iostream>
using namespace std;
struct st
{


}s1;
int main()
{
cout<<"sizeof(s1)="<<sizeof(s1)<<endl;
}

