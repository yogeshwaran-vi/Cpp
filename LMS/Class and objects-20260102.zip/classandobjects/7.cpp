#include<iostream>
using namespace std;
class A
{
public:
int x:4;
int y:5;
};
int main()
{
A ob1;


cout<<"sizeof(ob1)="<<sizeof(ob1)<<endl;

}
