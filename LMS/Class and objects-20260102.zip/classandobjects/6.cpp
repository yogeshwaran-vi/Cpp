//class and objects
#include<iostream>
using namespace std;
#pragma pack(2)
class A
{
public:
int x;
int y;
char ch;
};
int main()
{
A ob1,ob2;
cout<<"sizeof(object1)="<<sizeof(ob1)<<endl;
cout<<"sizeof(object2)="<<sizeof(ob2)<<endl;
}

