//call by reference
#include<iostream>
using namespace std;
void fun(int &p,int &q);// function declaration
int main()
{
int x=10,y=20;
fun(x,y);
cout<<"actual arguments"<<endl;
cout<<"x="<<x<<endl;//
cout<<"y="<<y<<endl;//
cout<<"address of x="<<&x<<endl;//1000
cout<<"address of y="<<&y<<endl;//2000
}
void fun(int &p,int &q) //function definition
{
p=35;
q=45;
cout<<"formal arguments"<<endl;
cout<<"p="<<p<<endl;//
cout<<"q="<<q<<endl;//
cout<<"address of p="<<&p<<endl;//1000
cout<<"address of q="<<&q<<endl;//2000
}

