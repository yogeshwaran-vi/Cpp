//call by value
#include<iostream>
using namespace std;
void fun(int a,int b);//function declaration
int main()
{
int x=10,y=20;

fun(x,y);//value of variable passed to the function 
cout<<"actual arguments"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
cout<<"address of x="<<&x<<endl;
cout<<"address of y="<<&y<<endl;
}
void fun(int a,int b) //function definition
{
//NOTE:
//Any changes made inside the function,it will affect formal
//arguments only.

a=35;
b=45;
cout<<"formal arguments"<<endl;
cout<<"a="<<a<<endl;
cout<<"b="<<b<<endl;
cout<<"address of a="<<&a<<endl;
cout<<"address of b="<<&b<<endl;
}
