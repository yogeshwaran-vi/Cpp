//call by reference
#include<iostream>
using namespace std;
void fun(int &p,int &q);// function declaration
int main()
{
int x=10,y=20;
cout<<"before swapping"<<endl;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
fun(x,y);
cout<<"after swapping"<<endl;
cout<<"x="<<x<<endl;//
cout<<"y="<<y<<endl;//
cout<<"address of x="<<&x<<endl;//1000
cout<<"address of y="<<&y<<endl;//2000
}
void fun(int &p,int &q) //function definition
{
int temp;
temp=p;
p=q;
q=temp;
}

