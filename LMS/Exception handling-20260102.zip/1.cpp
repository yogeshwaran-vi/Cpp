#include<iostream>
using namespace std;
int main()
{
int x,y,z;
cout<<"enter the x and y value.."<<endl;
cin>>x>>y;
z=x/y;
cout<<"x="<<x<<endl;
cout<<"y="<<y<<endl;
cout<<"z="<<z<<endl;
}


