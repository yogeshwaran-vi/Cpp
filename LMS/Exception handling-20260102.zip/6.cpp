#include<iostream>
using namespace std;
void fun()
{
throw "hi";
}
int main()
{
try
{
fun();
}
catch(const char *p)
{
cout<<"p="<<p<<endl;
}
}


