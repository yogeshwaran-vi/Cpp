#include<iostream>
using namespace std;
int  main()
{
int op;
try
{
cout<<"enter the option 1) int  2)char "<<endl;
cin>>op;
switch(op)
{
case 1: throw 10;
        break;

case 2:throw 'A'; //Whenever  exception was rasied, No catch block found means
                  //then, it will call one standard  library function is terminate () function.                   // terminate function is used terminate program forcefully
       break;

default:cout<<"invalid option"<<endl;
}
}
catch(int x)
{
cout<<"x="<<x<<endl;
}

}
