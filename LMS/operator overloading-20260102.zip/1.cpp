#include<iostream>
using namespace std;
int main()
{
int a=10,b=20,c;

c=a+b;
cout<<"c="<<c<<endl;


}

