//post increment operator function using member function

syntax:
returntype operator++(int a)
{
----------------------------
-----------------------------
-----------------------------

}
