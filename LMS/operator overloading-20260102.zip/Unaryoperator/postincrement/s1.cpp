//Assignment 
//W.A.P to impliment post decrement operator function using member function
syntax:
returntype operator--(int a)
{
---------------------------
---------------------------
-------------------------
}

ob2=ob1--;

//W.a.p to impliment post decrement operator function using friend function

syntax:

returntype operator--(classname &,int a)
{
----------------------------------------
-------------------------------------
}

ob2=ob1--;
