//unary operator as  a member function
//operator function doesn't required any argument
#include<iostream>
using namespace std;
class A
{
private:
int x;// data member
public:
A()
{
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
A(int a)
{
x=a;
cout<<"parameterized constructor"<<endl;
cout<<"x="<<x<<endl;
}
A operator++();// operator function declaration
void print()
{
cout<<"x="<<x<<endl;
}
};
A A::operator++() //
{
cout<<"preincrement operator function"<<endl;
A temp;
temp.x=++x;
return temp;
}

int main()
{
A ob1(10),ob2;
cout<<"display the ob1 data"<<endl;
ob1.print();
ob2=++ob1;//ob1.operator++()
          // ob1 going to invoke preincrement operator function
cout<<"display the ob2 data"<<endl;
ob2.print();
cout<<"display the ob1 data"<<endl;
ob1.print();
}


