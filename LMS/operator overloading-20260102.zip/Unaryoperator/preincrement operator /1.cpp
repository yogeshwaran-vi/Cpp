//preincrement operator
#include<iostream>
using namespace std;
int main()
{
int x=10,z;

z=++x;

cout<<"x="<<x<<endl;
cout<<"z="<<z<<endl;

}
