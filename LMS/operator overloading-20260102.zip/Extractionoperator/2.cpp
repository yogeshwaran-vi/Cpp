//>> (extraction operator)
#include<iostream>
using namespace std;
class A
{
	protected:
		int x;// data member 
	friend istream & operator>>(istream &in,A &ob4);

};
istream &  operator>>(istream   &in,A   &ob4) //non-member function ,it is not part of class
{
cout<<"extraction operator function is called"<<endl;
in>>ob4.x;
return in;// reference object return cin

}


int main()
{
	A ob1,ob2;
	cin>>ob1>>ob2; // step1:
	               // cin>>ob1;
		       //operator>>(cin,ob1);
		       //it is going to invoke extraction operator function
		       //cin
		       //step2:
		       //cin>>ob2;
		       //operator>>(cin,ob2)
		       //it is going to invoke extraction  operator function
		       //cin


}
