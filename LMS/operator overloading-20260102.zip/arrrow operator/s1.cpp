//arrow operator
Syntax:

returntype * operator->()
{
-----------------------
-----------------------
----------------------
}
