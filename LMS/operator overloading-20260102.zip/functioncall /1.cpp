//function call operator function
//using member function
#include<iostream>
using namespace std;
class A
{
	private:
		int x;// data member 
	public:
	A()
	{
	cout<<"default constructor"<<endl;
	cout<<"x="<<x<<endl;
	}
	A(int a)
	{
	x=a;
	cout<<"parameterized constructor"<<endl;
	cout<<"x="<<x<<endl;
	}
	void operator()(int j)
	{
	cout<<"function call operator function is called"<<endl;
	cout<<"j="<<j<<endl; //20
	}

};
int main()
{
	A ob1;//invoke default constructor

	ob1(20);//ob1.operator()(20)
                //ob1 going to invoke function call operator function	





}
