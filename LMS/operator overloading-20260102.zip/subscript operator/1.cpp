//Subscripting operator function []
//using member function
#include<iostream>
using namespace std;
class A
{
	private:
		int a[5];//data member 
		int i;
	public:
	A()
	{
	cout<<"default constructor"<<endl;
	cout<<"enter the elements"<<endl;
	for(i=0;i<5;i++)
	{
	cin>>a[i];
	}

	}
	void operator[](int j)
	{
	cout<<"subscript operator function is called"<<endl;
	cout<<"a["<<j<<"]="<<a[j]<<endl;
	}

};
int main()
{
	A ob1;//invoke default constructor
        int i;
	for(i=0;i<5;i++)
	{
	ob1[i];//ob1.operator[](i)
	       // ob1 going to invoke subscript operator function
	       // one argument passed to the subscript operator function explicitly
	}




}
