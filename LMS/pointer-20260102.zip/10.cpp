//pointer
#include<iostream>
using namespace std;
int main()
{
int x=10;
int *p=&x;
cout<<"x="<<x<<endl;//10
cout<<"&x="<<&x<<endl;//1000
cout<<"p="<<p<<endl;//1000
cout<<"*p="<<*p<<endl;//*(1000)=10
cout<<"&p="<<&p<<endl;//2000

}
