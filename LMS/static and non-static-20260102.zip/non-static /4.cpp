//non-static data member   is a part of object
#include<iostream>
using namespace std;
class A
{
protected:
int x;// non-static data member 
public:
A():x(10) //valid 
{
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
};
int main()
{
A ob1,ob2;


}
