#include<iostream>
using namespace std;
class A
{
public:
int x;// non-static data member 
};
int main()
{
A ob1,ob2;

cout<<"ob1.x="<<ob1.x<<endl;
cout<<"ob2.x="<<ob2.x<<endl;
}

//NOTE:
//non-static data member is a part of object.

