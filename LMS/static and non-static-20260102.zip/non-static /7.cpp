#include<iostream>
using namespace std;
class A
{
private:
int x;// non-static data member
public:
void setdata() //non-static member function
{
cout<<"enter the x value.."<<endl;
cin>>x;
}
void print() //non-static member function
{
cout<<"x="<<x<<endl;
}
};
int main()
{
cout<<"using classname"<<endl;
A::setdata(); //invalid
A::print(); //invalid 
}
//NOTE:
//non-static member function is a part of object.

