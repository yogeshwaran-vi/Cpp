#include<iostream>
using namespace std;
class A
{
private:
int x;//non-static data member
public:
static void setdata() //static member function
{
cout<<"enter the x value.."<<endl;
cin>>x;
}
static void print() //static member function
{
cout<<"x="<<x<<endl;
}
};
int main()
{
A ob1;
cout<<"enter the ob1 data"<<endl;
ob1.setdata();
cout<<"display the ob1 data"<<endl;
ob1.print();
}
//NOTE:
//static member function cannot be accessed non-static data member 

