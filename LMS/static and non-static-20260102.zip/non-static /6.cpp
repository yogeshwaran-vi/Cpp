#include<iostream>
using namespace std;
class A
{
private:
int x;// non-static data member
public:
void setdata() //non-static member function
{
cout<<"enter the x value.."<<endl;
cin>>x;
}
void print() //non-static member function
{
cout<<"x="<<x<<endl;
}
};
int main()
{
A ob1;
cout<<"enter the ob1 data"<<endl;
ob1.setdata();
cout<<"display the ob1 data"<<endl;
ob1.print();
}

