//private constructor 
#include<iostream>
using namespace std;
class A
{
 static int x;// by default,private static data member 

A() //by default,private constructor
{
++x;
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
public:
static void fun() //static member function
{
A  ob1,ob2;

}
static void print()
{
cout<<"x="<<x<<endl;
}
};
int  A::x;// static definition
int main()
{
cout<<"using class name"<<endl;
A::fun();
cout<<"using class name"<<endl;
A::print();

}

