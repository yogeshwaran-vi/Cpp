#include<iostream>
using namespace std;
class A
{
 int x;// by default,private data member 

A() //by default,private constructor
{
cout<<"default constructor"<<endl;
cout<<"x="<<x<<endl;
}
};
int main()
{
A ob1;


}
