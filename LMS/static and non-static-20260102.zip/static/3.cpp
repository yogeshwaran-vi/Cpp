#include<iostream>
using namespace std;
class A
{
public:
static int x;// static data member 
};
int A::x;//static definition  

int main()
{
cout<<"using class name"<<endl;
cin>>A::x;
cout<<"A::x="<<A::x<<endl;
}

//NOTE:
//static data member is a part of class




