#include<iostream>
using namespace std;
class A
{
public:
static int x=10;//static data member 
};
int A::x;// static definition
int main()
{
A ob1,ob2;

cout<<"ob1.x="<<ob1.x<<endl;
cout<<"ob2.x="<<ob2.x<<endl;
}


 
