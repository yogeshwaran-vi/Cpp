//static member function is a part of class 
#include<iostream>
using namespace std;
class A
{
private:
static int x;// static data member
public:
static void print()//static member function
{
cout<<"x="<<x<<endl;
}
};
int A::x=10;// static definition

int main()
{
cout<<"using class name"<<endl;
A::print();
}


