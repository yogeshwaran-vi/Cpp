#include<iostream>
using namespace std;
class A
{
private:
static int x;// static data member
public:
static void print()//static member function
{
cout<<"x="<<x<<endl;
}

};
int A::x=10;// static definition

int main()
{
A ob1,ob2;
cout<<"display the ob1 data"<<endl;
ob1.print();
cout<<"display the ob2 data"<<endl;
ob2.print();
}


