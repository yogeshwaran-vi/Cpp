//virtual function
#include<iostream>
using namespace std;
//base class
#pragma pack(4)
class A
{
public:
int x; //data member 
int y;
int z;
public:
virtual void print()
{
cout<<"base class member function is called"<<endl;
}
virtual void setdata()
{
cout<<"base class member function is called"<<endl;
}
};
//derived class
class B:public A
{
//derived class inherits all the properties from base class
//internally
//public:
//int x;
//int y;
//int z;
//public:
//virtual void print()
//{
//}
//virtual void setdata()
//{
//}
};
int main()
{
A a1[2];
B b1[2];
cout<<"sizeof(base class)="<<sizeof(a1)<<endl;
cout<<"sizeof(derived class)="<<sizeof(b1)<<endl;
}

