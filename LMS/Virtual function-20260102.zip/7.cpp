//Real Time Example
//virtual function
#include<iostream>
using namespace std;
//base class
class payment
{
public:
virtual void processpayment(double amount)
{
cout<<"base class member function"<<endl;
cout<<"cash amount paid sucessfully $="<<amount<<endl;
}
};
//derived 1 class
class UPI:public payment
{
public:
void processpayment(double amount)
{
cout<<"derived 1 class member function"<<endl;
cout<<"UPI amount paid sucessfully $="<<amount<<endl;
}
};
//derived 2 class
class Creditcard:public payment
{
public:
void processpayment(double amount)
{
cout<<"derived2 class member function"<<endl;
cout<<"Credit card amount paid successfully $="<<amount<<endl;
}
};
//derived 3 class
class Debitcard:public payment
{
public:
void processpayment(double amount)
{
cout<<"derived 3 class member function"<<endl;
cout<<"Debit card amount paid successfully $="<<amount<<endl;
}
};
//derived 4 class
class Walletpayment:public payment
{
public:
void processpayment(double amount)
{
cout<<"derived 4 class member function"<<endl;
cout<<"Walled payment paid success fully $="<<amount<<endl;
}
};
int main()
{
payment *p1;
int op;
cout<<"enter the option 1)UPI 2)creditcard 3)debitcard 4) Walletpayment 5)Exit"<<endl;
cin>>op;
switch(op)
{
case 1:p1=new UPI;
         break;
case 2:p1=new Creditcard;
        break;
case 3:p1=new Debitcard;
       break;
case 4:p1=new Walletpayment;
       break;
case 5:cout<<"EXIT"<<endl;
       return 0;
default:cout<<"invalid option"<<endl;
        return 0;
}
int d;
cout<<"enter the amount to pay"<<endl;
cin>>d;
p1->processpayment(d);
}
