//function overriding
#include<iostream>
using namespace std;
//base class
class A
{
 public:
void fun()
{
cout<<"base class member function is called"<<endl;
}
};
//derived class
class B:public A
{

public:
void fun()
{
cout<<"derived class member function is called"<<endl;
}
};
int main()
{
B b1;
b1.fun();//derived class member function executed
b1.A::fun();//base class member function executed
}

