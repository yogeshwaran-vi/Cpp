//virtual function
#include<iostream>
using namespace std;
//base class
class A
{
public:
virtual void test1()
{
cout<<"base class member function is called"<<endl;
}
};
//derived class
class B:public A
{
public:
void test1()
{
cout<<"derived class member function is called"<<endl;
}
};
int main()
{
B *ptr;
A a1;
ptr=&a1;//invalid,derived class pointer unable to hold base class object address
ptr->test1();
}
